# LL1-parser
LL1 parser written in Python

## Features
1. First and Follow Sets
2. LL1 parsing Table
3. String parsing function which takes string as Input and outputs whether the string is accepted or rejected by the grammar

